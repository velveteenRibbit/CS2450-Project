package myHangman;

import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.swing.Timer;
import java.util.Random;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.imageio.ImageIO;
import javax.swing.JLabel;


public class Play extends javax.swing.JFrame {

    public Play(Home homePanel, Highscores scorePanel) {
        initComponents();
        setBounds(300,300,600,434);
        setLocationRelativeTo(null);
        date();
        time();
        createDash(randomWord);
        createAlphabet();
        this.homePanel = homePanel;
        this.scorePanel = scorePanel;
    }
    
    public void date() {
        SimpleDateFormat sDate = new SimpleDateFormat("MMMM dd, yyyy");
        Date dDate = new Date();
        date.setText(sDate.format(dDate));
    }
    
    public void time() {
        Timer t = new Timer(0,new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SimpleDateFormat sDate = new SimpleDateFormat("hh:mm:ss");
                Date dTime = new Date();
                time.setText(sDate.format(dTime));
            }
        });
        t.start();    
    } 
    
    public void createDash(String randomWord) {
        dashLine = new JLabel[randomWord.length()];
        Container container = new Container();
        
        container.setLayout(new GridLayout(1, randomWord.length()));
        container.setBounds(100, 254, 400, 40);
        
        for(int i = 0; i < randomWord.length(); i++){
            dashLine[i] = new JLabel("_");
            container.add(dashLine[i]);
        }
        
        getContentPane().add(container);
    }
    
    
    public ArrayList<javax.swing.JButton> createAlphabet()
    {
        ArrayList<javax.swing.JButton> alphabetB = new ArrayList<>();
        int [] original = {5,300,40,40};
        int x = 5;
        int y = 300;
        int length = 40;
        int width = 40;
        int startButton = 1;
        
        //messed up namimng here, my bad
        hangMan1.setVisible(false);
        jLabel2.setVisible(false);
        hangMan2.setVisible(false);
        hangMan3.setVisible(false);
        hangMan4.setVisible(false);
        hangMan5.setVisible(false);
        
        for(char alphabet = 'a'; alphabet <= 'z'; alphabet++)
        {
            javax.swing.JButton alphaButtons = new javax.swing.JButton();
            alphaButtons.setBorder(null);
            alphaButtons.setFont(new java.awt.Font("Bauhaus 93", 2, 19));
            alphaButtons.setBackground(new java.awt.Color(0,0,0));
            alphaButtons.setForeground(new java.awt.Color(51, 102, 255));
            alphaButtons.setText("" + alphabet);
            alphaButtons.setOpaque(true);
            alphaButtons.setBounds(x, y, length, width);
            getContentPane().add(alphaButtons);
            x += 45;
            if(startButton == 13)
            {
                x = original[0];
                y += 50;
            }
            startButton++;
            alphabetB.add(alphaButtons);
            alphaButtons.setVisible(true);

            alphaButtons.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AllButtonActionPerformed(evt);
            }
                private void AllButtonActionPerformed(ActionEvent evt) {
                    
                    if(error == 0 && !(randomWord.contains(alphaButtons.getText()))){
                        score -= 10;
                        error++;
                        userScore.setText(Integer.toString(score));
                        alphaButtons.setVisible(false);
                        hangMan1.setVisible(true);
                    }
                    else if(error == 1 && !(randomWord.contains(alphaButtons.getText()))){
                        score -= 10;
                        error++;
                        userScore.setText(Integer.toString(score));
                        alphaButtons.setVisible(false);
                        jLabel2.setVisible(true);
                    }
                    else if(error == 2 && !(randomWord.contains(alphaButtons.getText()))){
                        score -= 10;
                        error++;
                        userScore.setText(Integer.toString(score));
                        hangMan2.setVisible(true);
                    }
                    else if(error == 3 && !(randomWord.contains(alphaButtons.getText()))){
                        score -= 10;
                        error++;
                        userScore.setText(Integer.toString(score));
                        alphaButtons.setVisible(false);
                        hangMan3.setVisible(true);
                    }
                    else if(error == 4 && !(randomWord.contains(alphaButtons.getText()))){
                        score -= 10;
                        error++;
                        userScore.setText(Integer.toString(score));
                        alphaButtons.setVisible(false);
                        hangMan4.setVisible(true);
                    }
                    else if(error == 5 && !(randomWord.contains(alphaButtons.getText()))){
                        score -= 10;
                        error++;
                        userScore.setText(Integer.toString(score));
                        alphaButtons.setVisible(false);
                        hangMan5.setVisible(true);
                    }
                    else if(error < 6 && (randomWord.contains(alphaButtons.getText()))){
                        for (int i = 0; i < randomWord.length(); i++) {
                            if (alphaButtons.getText().toLowerCase().charAt(0) == randomWord.charAt(i)) {
                                dashLine[i].setText(alphaButtons.getText());
                                counter[i] = true;
                        }
                        alphaButtons.setVisible(false);                        
                        }
                    }
                   
                    boolean win = true;
                    for(int i = 0; i < counter.length; i++){
                        if(!counter[i]){
                            win = false;
                        }
                    }
                    
                    if(win == true){
                        disposeObject();
                        homePanel.setVisible(true);
                        scorePanel.setScore(score);
                    }
                    
                    if(error == 6){
                        disposeObject();
                        homePanel.setVisible(true);
                        scorePanel.setScore(score);
                    }
                    
                }
            });
        }
        return alphabetB;
    }
    
    public int getScore(){
        return score;
    }
  
    public void disposeObject(){
        getContentPane().remove(this);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        skipButton = new javax.swing.JButton();
        date = new javax.swing.JLabel();
        time = new javax.swing.JLabel();
        title = new javax.swing.JLabel();
        scoreTitle = new javax.swing.JLabel();
        userScore = new javax.swing.JLabel();
        hiddenWordLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        hangMan1 = new javax.swing.JLabel();
        hangMan2 = new javax.swing.JLabel();
        hangMan3 = new javax.swing.JLabel();
        hangMan4 = new javax.swing.JLabel();
        hangMan5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(600, 400));
        setResizable(false);
        getContentPane().setLayout(null);

        skipButton.setBackground(new java.awt.Color(51, 102, 255));
        skipButton.setFont(new java.awt.Font("Bauhaus 93", 2, 14)); // NOI18N
        skipButton.setText("SKIP");
        skipButton.setBorder(null);
        skipButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                skipButtonActionPerformed(evt);
            }
        });
        getContentPane().add(skipButton);
        skipButton.setBounds(520, 30, 60, 29);

        date.setFont(new java.awt.Font("Bauhaus 93", 2, 18)); // NOI18N
        date.setForeground(new java.awt.Color(51, 102, 255));
        getContentPane().add(date);
        date.setBounds(340, 5, 170, 30);

        time.setFont(new java.awt.Font("Bauhaus 93", 2, 18)); // NOI18N
        time.setForeground(new java.awt.Color(51, 102, 255));
        getContentPane().add(time);
        time.setBounds(500, 5, 100, 30);

        title.setFont(new java.awt.Font("Bauhaus 93", 2, 24)); // NOI18N
        title.setForeground(new java.awt.Color(51, 102, 255));
        title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        title.setText("HANGMAN");
        getContentPane().add(title);
        title.setBounds(4, 4, 110, 40);

        scoreTitle.setFont(new java.awt.Font("Bauhaus 93", 2, 20)); // NOI18N
        scoreTitle.setForeground(new java.awt.Color(51, 102, 255));
        scoreTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        scoreTitle.setText("SCORE:");
        getContentPane().add(scoreTitle);
        scoreTitle.setBounds(230, 30, 80, 30);

        userScore.setFont(new java.awt.Font("Bauhaus 93", 2, 20)); // NOI18N
        userScore.setForeground(new java.awt.Color(51, 102, 255));
        userScore.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        userScore.setText("100");
        getContentPane().add(userScore);
        userScore.setBounds(310, 30, 40, 30);

        hiddenWordLabel.setFont(new java.awt.Font("Bauhaus 93", 2, 26)); // NOI18N
        hiddenWordLabel.setForeground(new java.awt.Color(51, 102, 255));
        hiddenWordLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(hiddenWordLabel);
        hiddenWordLabel.setBounds(100, 254, 400, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Hangman-0.png"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(120, 50, 290, 210);
        jLabel1.getAccessibleContext().setAccessibleName("hang1");

        hangMan1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Hangman-1.png"))); // NOI18N
        getContentPane().add(hangMan1);
        hangMan1.setBounds(120, 60, 360, 190);

        hangMan2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Hangman-3.png"))); // NOI18N
        getContentPane().add(hangMan2);
        hangMan2.setBounds(120, 60, 360, 190);

        hangMan3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Hangman-4.png"))); // NOI18N
        getContentPane().add(hangMan3);
        hangMan3.setBounds(120, 60, 360, 190);

        hangMan4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Hangman-5.png"))); // NOI18N
        getContentPane().add(hangMan4);
        hangMan4.setBounds(120, 60, 360, 190);

        hangMan5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Hangman-6.png"))); // NOI18N
        getContentPane().add(hangMan5);
        hangMan5.setBounds(120, 60, 360, 190);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Hangman-2.png"))); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(120, 50, 290, 210);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    
    private void skipButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_skipButtonActionPerformed
        // TODO add your handling code here:
        homePanel.setVisible(true);
        scorePanel.setScore(this.getScore());
        disposeObject();
    }//GEN-LAST:event_skipButtonActionPerformed


    
    private Random rand = new Random();
    private String[] wordBank = {"abstract", "cemetery", "nurse", "pharmacy", "climbing"};
    private String randomWord = wordBank[rand.nextInt(wordBank.length)];
    private JLabel[] dashLine;
    private boolean[] counter = new boolean[randomWord.length()];
    private int score = 100;
    private Home homePanel;
    private Highscores scorePanel;
    private BufferedImage pic = null;
    private int error = 0;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel date;
    private javax.swing.JLabel hangMan1;
    private javax.swing.JLabel hangMan2;
    private javax.swing.JLabel hangMan3;
    private javax.swing.JLabel hangMan4;
    private javax.swing.JLabel hangMan5;
    private javax.swing.JLabel hiddenWordLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel scoreTitle;
    private javax.swing.JButton skipButton;
    private javax.swing.JLabel time;
    private javax.swing.JLabel title;
    public javax.swing.JLabel userScore;
    // End of variables declaration//GEN-END:variables
}
