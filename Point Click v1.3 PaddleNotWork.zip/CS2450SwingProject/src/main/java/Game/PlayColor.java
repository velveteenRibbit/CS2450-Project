package Game;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.Timer;
import java.awt.Component;
import javax.swing.JButton;
import java.util.*;

/**
 * @author danie
 * 
 * TODO:
 *  randomize button colors
 *  highlight buttons when mouse hovers over it
 *  implement game logic
 */

public class PlayColor extends javax.swing.JFrame {

    //Creates new form PlayColor
    public PlayColor(Home homePanel, Highscores scorePanel, GameOver endPanel) {
        initComponents();
        setBounds(300,300,600,434);
        setLocationRelativeTo(null);
        date();
        time();
        this.homePanel = homePanel;
        this.scorePanel = scorePanel;
        this.endPanel = endPanel; 
        JButton[] buttonList = new JButton[5];
        components[0] = date; 
        components[1] = time; 
        components[2] = colorText; 
        for (int i=3; i<8; i++) {
            components[i] = colorText;
        }
        randomButtons();
    }
    
    // sets and displays clock
    public void date() {
        SimpleDateFormat sDate = new SimpleDateFormat("MMMM dd, yyyy");
        Date dDate = new Date();
        date.setText(sDate.format(dDate));
    }  
    public void time() {
        Timer t = new Timer(0,new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SimpleDateFormat sDate = new SimpleDateFormat("hh:mm:ss");
                Date dTime = new Date();
                time.setText(sDate.format(dTime));
            }
        });
        t.start();    
    } 
    
    // creates randomizes button location for 5 buttons, takes in user input
    private void randomButtons() {
        for (int i=0; i<buttonList.length; i++) {
            buttonList[i] = new JButton();
            do {
                buttonList[i].setBounds(rand.nextInt(500), rand.nextInt(300), 100, 100);
            } while(buttonIntersect(components, buttonList[i]));
            components[i+3] = buttonList[i];
            buttonList[i].setVisible(true);
            this.add(buttonList[i]);
            
            ActionListener buttonClicked = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (clickCount < 4) {
                    clickCount++;
                    removeButtons();
                    randomButtons();
                }
                else {
                    clickCount = 0;
                    endPanel.setVisible(true);
                    disposeObject();
                }
            }};
            
            buttonList[i].addActionListener(buttonClicked);
        }
    }
    
    // checks if buttons intersect with anything
    private boolean buttonIntersect(Component[] items, JButton button) {
        for (Component b : items) {
            if (button.getBounds().intersects(b.getBounds()))
                return true;
        }
        return false;
    }
    
    // removes all buttons from screen
    private void removeButtons(){
        for (int i=0; i<buttonList.length; i++) {
            buttonList[i].setEnabled(false);
            buttonList[i].setVisible(false);
        }
    }
    
    public void disposeObject(){
        this.setVisible(false);
        getContentPane().remove(this);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox1 = new javax.swing.JCheckBox();
        time = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        colorText = new javax.swing.JLabel();

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(600, 400));
        setMinimumSize(new java.awt.Dimension(600, 400));
        setResizable(false);

        time.setFont(new java.awt.Font("Bauhaus 93", 2, 18)); // NOI18N
        time.setForeground(new java.awt.Color(51, 102, 255));
        time.setText("[time]");

        date.setFont(new java.awt.Font("Bauhaus 93", 2, 18)); // NOI18N
        date.setForeground(new java.awt.Color(51, 102, 255));
        date.setText("[date]");

        colorText.setFont(new java.awt.Font("Bauhaus 93", 2, 24)); // NOI18N
        colorText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        colorText.setText("[COLOR]");
        colorText.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        colorText.setMaximumSize(new java.awt.Dimension(200, 100));
        colorText.setMinimumSize(new java.awt.Dimension(200, 100));
        colorText.setPreferredSize(new java.awt.Dimension(200, 100));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 201, Short.MAX_VALUE)
                .addComponent(colorText, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(199, 199, 199))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(110, 110, 110)
                .addComponent(colorText, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(212, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private JButton[] buttonList = new JButton[5];
    private final Home homePanel;
    private final Highscores scorePanel;
    private final GameOver endPanel;
    Random rand = new Random();
    private int clickCount = 0;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel colorText;
    private javax.swing.JLabel date;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel time;
    // End of variables declaration//GEN-END:variables
    private Component[] components = new Component[8];
}