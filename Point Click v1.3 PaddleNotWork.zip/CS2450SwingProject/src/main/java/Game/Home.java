package Game;

import javax.swing.JFrame;

/**
 * @author Arsh
 */
public class Home extends javax.swing.JFrame {

     // Creates new form Home  
    public Home() {
        initComponents();
        setBounds(300,300,600,434);
        setLocationRelativeTo(null);
    }
    
    public void setFrameToFalse(){
        frame1.getContentPane().removeAll();
        frame1.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        playButton = new javax.swing.JButton();
        highscoreButton = new javax.swing.JButton();
        creditButton = new javax.swing.JButton();
        symbol = new javax.swing.JLabel();
        whiteEyeBackGround = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        backGround = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(600, 400));
        setResizable(false);
        setSize(new java.awt.Dimension(600, 400));
        getContentPane().setLayout(null);

        playButton.setBackground(new java.awt.Color(51, 102, 255));
        playButton.setFont(new java.awt.Font("Bauhaus 93", 2, 24)); // NOI18N
        playButton.setText("PLAY");
        playButton.setBorder(null);
        playButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playButtonActionPerformed(evt);
            }
        });
        getContentPane().add(playButton);
        playButton.setBounds(410, 220, 170, 50);

        highscoreButton.setBackground(new java.awt.Color(51, 102, 255));
        highscoreButton.setFont(new java.awt.Font("Bauhaus 93", 2, 24)); // NOI18N
        highscoreButton.setText("HIGHSCORES");
        highscoreButton.setBorder(null);
        highscoreButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                highscoreButtonActionPerformed(evt);
            }
        });
        getContentPane().add(highscoreButton);
        highscoreButton.setBounds(410, 280, 170, 50);

        creditButton.setBackground(new java.awt.Color(51, 102, 255));
        creditButton.setFont(new java.awt.Font("Bauhaus 93", 2, 24)); // NOI18N
        creditButton.setText("CREDITS");
        creditButton.setBorder(null);
        creditButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                creditButtonActionPerformed(evt);
            }
        });
        getContentPane().add(creditButton);
        creditButton.setBounds(410, 340, 170, 50);

        symbol.setIcon(new javax.swing.ImageIcon(getClass().getResource("/output-onlinepngtools (1).png"))); // NOI18N
        getContentPane().add(symbol);
        symbol.setBounds(110, 70, 180, 220);
        getContentPane().add(whiteEyeBackGround);
        whiteEyeBackGround.setBounds(90, 110, 60, 25);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/676549.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(160, 160, 80, 30);
        getContentPane().add(backGround);
        backGround.setBounds(0, 0, 600, 400);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // goes to hangman gameplay screen
    private void playButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playButtonActionPerformed
        playPanel = new PlayHangman(this, scorePanel, g, c);
        playPanel.setVisible(true);
        this.setVisible(false);        
    }//GEN-LAST:event_playButtonActionPerformed

    // goes to high score screen
    private void highscoreButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_highscoreButtonActionPerformed
        scorePanel.setVisible(true);
        this.setVisible(false);        
    }//GEN-LAST:event_highscoreButtonActionPerformed

    // goes to credits screen
    private void creditButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_creditButtonActionPerformed
        creditPanel.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_creditButtonActionPerformed
    
    private PlayHangman playPanel;
    private final GameOver g = new GameOver(this, playPanel);
    private final Credits creditPanel = new Credits(this);
    private final Highscores scorePanel = new Highscores(this);
    private final PlayColor c = new PlayColor(this, scorePanel, g);
    private final JFrame frame1 = new JFrame();
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel backGround;
    private javax.swing.JButton creditButton;
    private javax.swing.JButton highscoreButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton playButton;
    private javax.swing.JLabel symbol;
    private javax.swing.JLabel whiteEyeBackGround;
    // End of variables declaration//GEN-END:variables
}
